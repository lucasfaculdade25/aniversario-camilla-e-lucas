import { randomUUID } from 'crypto'
import type { CollectionBeforeChangeHook, CollectionBeforeValidateHook, CollectionConfig } from 'payload'

const isAdmin = ({ req }: { req: { user?: { collection?: string } | null } }) =>
  req.user?.collection === 'admins'

const validateRSVP: CollectionBeforeValidateHook = async ({ data, operation, originalDoc, req }) => {
  const next = { ...(originalDoc ?? {}), ...(data ?? {}) }
  const name = typeof next.name === 'string' ? next.name.trim() : ''
  if (name.length < 2 || name.length > 100) throw new Error('Informe um nome válido.')
  if (!['yes', 'no', 'pending'].includes(next.response)) throw new Error('Resposta inválida.')

  const invitation = await req.payload.findGlobal({ slug: 'invitation', overrideAccess: true })
  const companions = Array.isArray(next.companions) ? next.companions : []
  const limit = invitation.allowCompanions ? Math.max(0, Number(invitation.companionLimit ?? 0)) : 0

  if (next.response !== 'yes' && companions.length) throw new Error('Acompanhantes só podem ser adicionados a uma confirmação positiva.')
  if (companions.length > limit) throw new Error(`O limite é de ${limit} acompanhante(s).`)
  if (companions.some((item: { name?: unknown }) => typeof item?.name !== 'string' || item.name.trim().length < 2)) {
    throw new Error('Informe o nome completo de cada acompanhante.')
  }

  if (operation === 'create') {
    next.editToken = randomUUID()
  } else if (req.user?.collection !== 'admins') {
    if (!data?.editToken || data.editToken !== originalDoc?.editToken) throw new Error('Não foi possível validar esta resposta.')
    next.editToken = originalDoc.editToken
  }

  return {
    ...next,
    name,
    companions: companions.map((item: { name: string }) => ({ ...item, name: item.name.trim() })),
  }
}

const preventTokenChange: CollectionBeforeChangeHook = ({ data, operation, originalDoc, req }) => {
  if (operation === 'update' && req.user?.collection !== 'admins') data.editToken = originalDoc.editToken
  return data
}

export const RSVPs: CollectionConfig = {
  slug: 'rsvps',
  labels: {
    singular: 'Convidado',
    plural: 'Convidados',
  },
  admin: {
    group: 'Convite',
    useAsTitle: 'name',
    defaultColumns: ['name', 'response', 'companions', 'updatedAt'],
    description: 'Confirmações, recusas e acompanhantes do evento.',
    components: {
      beforeList: ['@/components/admin/EventDashboard#GuestListHeader'],
    },
  },
  access: {
    create: () => true,
    read: isAdmin,
    update: () => true,
    delete: isAdmin,
  },
  hooks: {
    beforeValidate: [validateRSVP],
    beforeChange: [preventTokenChange],
  },
  endpoints: [
    {
      path: '/export',
      method: 'get',
      handler: async (req) => {
        if (req.user?.collection !== 'admins') return Response.json({ error: 'Não autorizado.' }, { status: 401 })

        const allDocs = []
        let page = 1
        let hasNextPage = true
        while (hasNextPage) {
          const result = await req.payload.find({
            collection: 'rsvps',
            limit: 100,
            page,
            sort: 'name',
            overrideAccess: false,
            user: req.user,
          })
          allDocs.push(...result.docs)
          hasNextPage = result.hasNextPage
          page += 1
        }

        const cell = (value: unknown) => `"${String(value ?? '').replaceAll('"', '""')}"`
        const labels = { yes: 'Vai', no: 'Não vai', pending: 'Aguardando' }
        const rows = allDocs.map((doc) => [
          cell(doc.name),
          cell(labels[doc.response]),
          cell(doc.companions?.map((companion) => companion.name).join('; ') ?? ''),
          cell(doc.companions?.length ?? 0),
          cell(new Intl.DateTimeFormat('pt-BR').format(new Date(doc.updatedAt))),
        ].join(','))
        const csv = ['Nome,Resposta,Acompanhantes,Quantidade,Data', ...rows].join('\n')

        return new Response(`\uFEFF${csv}`, {
          headers: {
            'Content-Type': 'text/csv; charset=utf-8',
            'Content-Disposition': 'attachment; filename="lista-de-convidados.csv"',
          },
        })
      },
    },
  ],
  fields: [
    { name: 'name', label: 'Nome', type: 'text', required: true, maxLength: 100 },
    {
      name: 'response',
      label: 'Resposta',
      type: 'select',
      required: true,
      defaultValue: 'pending',
      options: [
        { label: 'Vai', value: 'yes' },
        { label: 'Não vai', value: 'no' },
        { label: 'Aguardando', value: 'pending' },
      ],
    },
    {
      name: 'companions',
      label: 'Acompanhantes',
      type: 'array',
      fields: [{ name: 'name', label: 'Nome', type: 'text', required: true, maxLength: 100 }],
    },
    {
      name: 'editToken',
      type: 'text',
      required: true,
      unique: true,
      admin: { hidden: true },
    },
  ],
}

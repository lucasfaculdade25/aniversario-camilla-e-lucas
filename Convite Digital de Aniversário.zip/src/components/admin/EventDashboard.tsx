import Image from 'next/image'
import type { PayloadRequest } from 'payload'
import './event-dashboard.css'

function getImageUrl(image: unknown) {
  return image && typeof image === 'object' && 'url' in image && typeof image.url === 'string' ? image.url : null
}

async function getMetrics(req: PayloadRequest) {
  const [invitation, yes, no, pending, confirmedDocs] = await Promise.all([
    req.payload.findGlobal({ slug: 'invitation', overrideAccess: false, user: req.user }),
    req.payload.count({ collection: 'rsvps', where: { response: { equals: 'yes' } }, overrideAccess: false, user: req.user }),
    req.payload.count({ collection: 'rsvps', where: { response: { equals: 'no' } }, overrideAccess: false, user: req.user }),
    req.payload.count({ collection: 'rsvps', where: { response: { equals: 'pending' } }, overrideAccess: false, user: req.user }),
    req.payload.find({ collection: 'rsvps', where: { response: { equals: 'yes' } }, limit: 100, pagination: false, overrideAccess: false, user: req.user }),
  ])
  const companions = confirmedDocs.docs.reduce((total, doc) => total + (doc.companions?.length ?? 0), 0)
  const days = invitation.date
    ? Math.max(0, Math.ceil((new Date(invitation.date).getTime() - Date.now()) / 86_400_000))
    : 0
  return {
    invitation,
    days,
    yes: yes.totalDocs,
    no: no.totalDocs,
    pending: pending.totalDocs,
    companions,
    people: yes.totalDocs + companions,
  }
}

export async function EventDashboard({ req }: { req: PayloadRequest }) {
  const data = await getMetrics(req)
  const image = getImageUrl(data.invitation.heroImage)
  return (
    <div className="event-admin">
      <section className="event-dashboard">
        <div className="event-dashboard__identity">
          <div>
            <span>Seu convite</span>
            <h2>{data.invitation.title}</h2>
            <p>{data.invitation.hosts}</p>
          </div>
          <div className="event-dashboard__thumb">
            {image ? <Image src={image} alt={`Capa de ${data.invitation.title}`} width={108} height={108} /> : <span>Sem foto</span>}
          </div>
        </div>
        <div className="event-dashboard__summary">
          <Summary label="Faltam" value={`${data.days} dias`} />
          <Summary label="Confirmados" value={data.yes} />
          <Summary label="Acompanhantes" value={data.companions} />
          <Summary label="Total de pessoas" value={data.people} />
        </div>
      </section>

      <nav className="event-dashboard__tabs">
        <a href="/admin/globals/invitation">Convite</a>
        <a href="/admin/collections/rsvps">Confirmações</a>
        <a href="/" target="_blank" rel="noreferrer">Ver página pública</a>
      </nav>

      <section className="event-dashboard__workspace">
        <div>
          <span>Gestão do evento</span>
          <h3>Confirmações e convidados</h3>
          <p>Acompanhe respostas, acompanhantes e pessoas confirmadas em um só lugar.</p>
        </div>
        <div className="event-dashboard__actions">
          <a href="/api/rsvps/export">Baixar lista</a>
          <a href="/admin/collections/rsvps/create" className="event-dashboard__action--primary">Adicionar convidado</a>
        </div>
      </section>

      <div className="event-dashboard__grid">
        <Metric label="Todos convidados" value={data.yes + data.no + data.pending} tone="dark" />
        <Metric label="Vão" value={data.yes} tone="green" />
        <Metric label="Não vão" value={data.no} tone="red" />
        <Metric label="Aguardando" value={data.pending} tone="neutral" />
      </div>
    </div>
  )
}

export async function GuestListHeader({ req }: { req: PayloadRequest }) {
  const data = await getMetrics(req)
  return (
    <div className="guest-list-panel">
      <div className="guest-list-header">
        <div>
          <span>Lista de presença</span>
          <h2>Convidados</h2>
          <p>Busque, filtre, adicione ou edite as respostas do evento.</p>
        </div>
        <div className="guest-list-header__actions">
          <a href="/api/rsvps/export">Baixar lista</a>
          <a href="/admin/collections/rsvps/create" className="guest-list-header__primary">Adicionar convidado</a>
        </div>
      </div>
      <div className="guest-list-metrics">
        <Metric label="Todos convidados" value={data.yes + data.no + data.pending} tone="dark" />
        <Metric label="Vão" value={data.yes} tone="green" />
        <Metric label="Não vão" value={data.no} tone="red" />
        <Metric label="Aguardando" value={data.pending} tone="neutral" />
      </div>
      <p className="guest-list-total">{data.companions} acompanhante(s) · {data.people} pessoa(s) confirmada(s)</p>
    </div>
  )
}

function Metric({ label, value, tone }: { label: string; value: number; tone: string }) {
  return <div className={`event-dashboard__metric event-dashboard__metric--${tone}`}><span>{label}</span><strong>{value}</strong></div>
}

function Summary({ label, value }: { label: string; value: number | string }) {
  return <div className="event-dashboard__summary-item"><span>{label}</span><strong>{value}</strong></div>
}

export default EventDashboard

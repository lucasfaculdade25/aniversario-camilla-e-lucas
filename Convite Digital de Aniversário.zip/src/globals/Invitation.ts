import { revalidateTag } from 'next/cache'
import type { GlobalConfig } from 'payload'

const isAdmin = ({ req }: { req: { user?: { collection?: string } | null } }) =>
  req.user?.collection === 'admins'

export const Invitation: GlobalConfig = {
  slug: 'invitation',
  label: 'Configurações do convite',
  access: {
    read: () => true,
    update: isAdmin,
  },
  admin: {
    group: 'Convite',
  },
  hooks: {
    afterChange: [
      () => {
        revalidateTag('invitation', 'max')
      },
    ],
  },
  fields: [
    {
      type: 'tabs',
      tabs: [
        {
          label: 'Evento',
          fields: [
            { name: 'eyebrow', label: 'Chamada', type: 'text', defaultValue: 'Você é nosso convidado' },
            { name: 'title', label: 'Título', type: 'text', required: true, defaultValue: 'Um brinde à vida' },
            { name: 'hosts', label: 'Aniversariantes', type: 'text', required: true, defaultValue: 'Marina & Caio' },
            { name: 'heroImage', label: 'Foto principal', type: 'upload', relationTo: 'media' },
            { name: 'date', label: 'Data', type: 'date', required: true, admin: { date: { pickerAppearance: 'dayOnly' } } },
            { name: 'time', label: 'Horário', type: 'text', required: true, defaultValue: '19:30' },
            { name: 'venue', label: 'Local', type: 'text', required: true, defaultValue: 'Casa Manioca' },
            { name: 'address', label: 'Endereço', type: 'textarea', required: true, defaultValue: 'Rua Joaquim Antunes, 210 — Pinheiros, São Paulo' },
            { name: 'mapsUrl', label: 'Link do Google Maps', type: 'text', required: true, defaultValue: 'https://maps.google.com/?q=Casa+Manioca+Sao+Paulo' },
          ],
        },
        {
          label: 'Mensagem',
          fields: [
            {
              name: 'message',
              label: 'Mensagem dos aniversariantes',
              type: 'textarea',
              required: true,
              defaultValue: 'A vida fica mais bonita quando é compartilhada. Queremos celebrar esse novo ciclo ao lado de quem faz parte da nossa história.',
            },
          ],
        },
        {
          label: 'Confirmação',
          fields: [
            { name: 'rsvpDeadline', label: 'Prazo para confirmação', type: 'date', required: true, admin: { date: { pickerAppearance: 'dayOnly' } } },
            { name: 'allowCompanions', label: 'Permitir acompanhantes', type: 'checkbox', defaultValue: true },
            { name: 'companionLimit', label: 'Limite por convidado', type: 'number', min: 0, max: 10, defaultValue: 3, admin: { condition: (_, siblingData) => Boolean(siblingData.allowCompanions) } },
          ],
        },
        {
          label: 'Aparência',
          fields: [
            {
              name: 'appearance',
              label: 'Cores',
              type: 'group',
              fields: [
                { name: 'accent', label: 'Cor de destaque', type: 'text', defaultValue: '#B64A32' },
                { name: 'background', label: 'Cor de fundo', type: 'text', defaultValue: '#F4EFE8' },
                { name: 'ink', label: 'Cor do texto', type: 'text', defaultValue: '#20231F' },
              ],
            },
          ],
        },
      ],
    },
  ],
}

import config from '@payload-config'
import { unstable_cache } from 'next/cache'
import { getPayload } from 'payload'

export const getInvitation = unstable_cache(
  async () => {
    const payload = await getPayload({ config })
    return payload.findGlobal({ slug: 'invitation', depth: 1 })
  },
  ['invitation'],
  { tags: ['invitation'] },
)

'use client'

import { useEffect, useState, useTransition } from 'react'
import { saveRSVP } from '../actions/rsvp'
import { Icon } from './icons'

type SavedRSVP = {
  id: string | number
  editToken: string
  name: string
  response: 'yes' | 'no'
  companions: string[]
}

const storageKey = 'convite-rsvp'

export function RSVPFlow({ companionLimit, allowCompanions, deadline }: { companionLimit: number; allowCompanions: boolean; deadline: string }) {
  const [open, setOpen] = useState(false)
  const [step, setStep] = useState(0)
  const [response, setResponse] = useState<'yes' | 'no' | null>(null)
  const [name, setName] = useState('')
  const [companions, setCompanions] = useState<string[]>([])
  const [companionDraft, setCompanionDraft] = useState('')
  const [saved, setSaved] = useState<SavedRSVP | null>(null)
  const [error, setError] = useState('')
  const [pending, startTransition] = useTransition()

  useEffect(() => {
    try {
      const value = window.localStorage.getItem(storageKey)
      if (value) setSaved(JSON.parse(value))
    } catch {
      window.localStorage.removeItem(storageKey)
    }
  }, [])

  const begin = (editing = false) => {
    setError('')
    if (editing && saved) {
      setResponse(saved.response)
      setName(saved.name)
      setCompanions(saved.companions)
      setStep(0)
    } else {
      setResponse(null)
      setName('')
      setCompanions([])
      setStep(0)
    }
    setOpen(true)
  }

  const addCompanion = () => {
    const value = companionDraft.trim()
    if (value.length < 2) return setError('Digite o nome do acompanhante.')
    if (companions.length >= companionLimit) return setError(`Você pode adicionar até ${companionLimit} acompanhante(s).`)
    setCompanions([...companions, value])
    setCompanionDraft('')
    setError('')
  }

  const finish = () => {
    if (!response || name.trim().length < 2) return setError('Revise seu nome e sua resposta.')
    startTransition(async () => {
      const result = await saveRSVP({
        id: saved?.id,
        editToken: saved?.editToken,
        name,
        response,
        companions,
      })
      if (!result.ok) return setError(result.message)
      const nextSaved: SavedRSVP = { id: result.id, editToken: result.editToken, name: name.trim(), response, companions }
      window.localStorage.setItem(storageKey, JSON.stringify(nextSaved))
      setSaved(nextSaved)
      setStep(3)
      setError('')
    })
  }

  return (
    <>
      <section id="rsvp" className="mt-8 rounded-2xl border border-black/10 bg-[var(--paper)] p-5 sm:flex sm:items-center sm:justify-between sm:gap-5">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[var(--accent)]">Confirmação de presença</p>
          <h2 className="mt-2 text-lg font-semibold text-[var(--ink)]">{saved ? (saved.response === 'yes' ? 'Você confirmou presença' : 'Você informou que não irá') : 'Você vem celebrar com a gente?'}</h2>
          <p className="mt-1 text-xs leading-5 text-black/45">
            {saved ? `Resposta salva para ${saved.name}.` : `Confirme até ${deadline}.`}
          </p>
        </div>
        <div className="mt-4 shrink-0 sm:mt-0">
          <button onClick={() => begin(Boolean(saved))} className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-full bg-[var(--accent)] px-5 text-xs font-semibold text-white transition hover:-translate-y-0.5 hover:brightness-110 sm:w-auto">
            {saved ? 'Editar resposta' : 'Confirmar presença'} <Icon name="arrow" className="size-4" />
          </button>
        </div>
      </section>

      {open && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/55 p-0 backdrop-blur-sm sm:items-center sm:p-6" role="dialog" aria-modal="true" aria-label="Confirmação de presença">
          <div className="max-h-[92dvh] w-full overflow-y-auto rounded-t-[2rem] bg-[#faf8f4] p-6 shadow-2xl sm:max-w-lg sm:rounded-[2rem] sm:p-9">
            <div className="mb-8 flex items-center justify-between">
              <div className="flex gap-1.5">
                {[0, 1, 2, 3].map((item) => <span key={item} className={`h-1.5 rounded-full transition-all ${item <= step ? 'w-7 bg-[var(--accent)]' : 'w-3 bg-black/10'}`} />)}
              </div>
              <button onClick={() => setOpen(false)} className="grid size-10 place-items-center rounded-full border border-black/10 text-black/50 hover:bg-black/5" aria-label="Fechar"><Icon name="close" className="size-5" /></button>
            </div>

            {step === 0 && (
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[var(--accent)]">Confirmação</p>
                <h3 className="font-display mt-3 text-4xl text-[var(--ink)]">Você vem?</h3>
                <p className="mt-3 text-sm leading-6 text-black/55">Escolha uma opção para continuar.</p>
                <div className="mt-8 grid gap-3">
                  <button onClick={() => { setResponse('yes'); setStep(1) }} className="flex min-h-16 items-center justify-between rounded-2xl border border-black/10 bg-white px-5 text-left font-semibold text-[var(--ink)] hover:border-[var(--accent)]"><span>Sim, eu vou</span><span className="grid size-8 place-items-center rounded-full bg-[#e9f2e6] text-[#497448]"><Icon name="check" className="size-4" /></span></button>
                  <button onClick={() => { setResponse('no'); setCompanions([]); setStep(1) }} className="flex min-h-16 items-center justify-between rounded-2xl border border-black/10 bg-white px-5 text-left font-semibold text-[var(--ink)] hover:border-[var(--accent)]"><span>Não vou conseguir</span><span className="grid size-8 place-items-center rounded-full bg-black/5 text-black/35"><Icon name="close" className="size-4" /></span></button>
                </div>
              </div>
            )}

            {step === 1 && (
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[var(--accent)]">Sobre você</p>
                <h3 className="font-display mt-3 text-4xl text-[var(--ink)]">Como podemos te chamar?</h3>
                <label className="mt-8 block text-sm font-semibold text-[var(--ink)]">Nome completo
                  <input autoFocus value={name} onChange={(event) => setName(event.target.value)} placeholder="Digite seu nome" className="mt-2 h-14 w-full rounded-2xl border border-black/10 bg-white px-4 outline-none transition focus:border-[var(--accent)]" />
                </label>
                <button onClick={() => name.trim().length >= 2 ? setStep(response === 'yes' && allowCompanions && companionLimit > 0 ? 2 : 2) : setError('Informe seu nome completo.')} className="mt-7 flex min-h-13 w-full items-center justify-center gap-2 rounded-full bg-[var(--ink)] px-6 text-sm font-semibold text-white">Continuar <Icon name="arrow" className="size-4" /></button>
              </div>
            )}

            {step === 2 && (
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[var(--accent)]">Revise sua resposta</p>
                <h3 className="font-display mt-3 text-4xl text-[var(--ink)]">{response === 'yes' ? 'Quem vai celebrar?' : 'Está tudo certo?'}</h3>
                <div className="mt-7 rounded-2xl border border-black/10 bg-white p-4">
                  <div className="flex items-center justify-between">
                    <div><p className="font-semibold text-[var(--ink)]">{name}</p><p className="mt-1 text-xs text-black/45">{response === 'yes' ? 'Presença confirmada' : 'Não poderá comparecer'}</p></div>
                    <button onClick={() => setStep(1)} className="grid size-9 place-items-center rounded-full bg-black/5" aria-label="Editar nome"><Icon name="edit" className="size-4" /></button>
                  </div>
                  {companions.map((item, index) => (
                    <div key={`${item}-${index}`} className="mt-3 flex items-center justify-between border-t border-black/5 pt-3">
                      <div><p className="text-sm font-medium">{item}</p><p className="text-xs text-black/40">Acompanhante</p></div>
                      <div className="flex gap-1">
                        <button onClick={() => { setCompanionDraft(item); setCompanions(companions.filter((_, itemIndex) => itemIndex !== index)) }} className="grid size-9 place-items-center rounded-full text-black/40 hover:bg-black/5 hover:text-black" aria-label={`Editar ${item}`}><Icon name="edit" className="size-4" /></button>
                        <button onClick={() => setCompanions(companions.filter((_, itemIndex) => itemIndex !== index))} className="grid size-9 place-items-center rounded-full text-black/40 hover:bg-red-50 hover:text-red-600" aria-label={`Excluir ${item}`}><Icon name="trash" className="size-4" /></button>
                      </div>
                    </div>
                  ))}
                </div>

                {response === 'yes' && allowCompanions && companions.length < companionLimit && (
                  <div className="mt-4 flex gap-2">
                    <input value={companionDraft} onChange={(event) => setCompanionDraft(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); addCompanion() } }} placeholder="Nome do acompanhante" className="h-12 min-w-0 flex-1 rounded-xl border border-black/10 bg-white px-4 text-sm outline-none focus:border-[var(--accent)]" />
                    <button onClick={addCompanion} className="grid size-12 shrink-0 place-items-center rounded-xl bg-[var(--accent)] text-white" aria-label="Adicionar acompanhante"><Icon name="plus" className="size-5" /></button>
                  </div>
                )}
                {response === 'yes' && allowCompanions && <p className="mt-2 text-xs text-black/40">{companions.length} de {companionLimit} acompanhantes adicionados</p>}
                <button disabled={pending} onClick={finish} className="mt-7 flex min-h-13 w-full items-center justify-center gap-2 rounded-full bg-[var(--ink)] px-6 text-sm font-semibold text-white disabled:opacity-50">{pending ? 'Salvando...' : 'Finalizar confirmação'} <Icon name="check" className="size-4" /></button>
              </div>
            )}

            {step === 3 && (
              <div className="pb-4 text-center">
                <span className="mx-auto grid size-20 place-items-center rounded-full bg-[#e4eee0] text-[#497448]"><Icon name="check" className="size-9" /></span>
                <p className="mt-7 text-xs font-semibold uppercase tracking-[0.22em] text-[var(--accent)]">Resposta registrada</p>
                <h3 className="font-display mt-3 text-4xl text-[var(--ink)]">{response === 'yes' ? 'Nos vemos na festa!' : 'Obrigado por avisar'}</h3>
                <p className="mx-auto mt-4 max-w-sm text-sm leading-6 text-black/55">Sua resposta foi salva. Você pode voltar a esta página e alterá-la quando precisar.</p>
                <button onClick={() => setOpen(false)} className="mt-8 min-h-13 w-full rounded-full bg-[var(--ink)] px-6 text-sm font-semibold text-white">Concluir</button>
              </div>
            )}

            {error && <p className="mt-4 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700" role="alert">{error}</p>}
          </div>
        </div>
      )}
    </>
  )
}

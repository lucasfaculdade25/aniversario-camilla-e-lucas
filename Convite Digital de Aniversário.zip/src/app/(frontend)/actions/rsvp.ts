'use server'

import config from '@payload-config'
import { getPayload } from 'payload'

export type RSVPInput = {
  id?: string | number
  editToken?: string
  name: string
  response: 'yes' | 'no'
  companions: string[]
}

export type RSVPResult =
  | { ok: true; id: string | number; editToken: string }
  | { ok: false; message: string }

export async function saveRSVP(input: RSVPInput): Promise<RSVPResult> {
  const name = typeof input.name === 'string' ? input.name.trim() : ''
  const response = input.response
  const companions = Array.isArray(input.companions)
    ? input.companions.map((item) => (typeof item === 'string' ? item.trim() : '')).filter(Boolean)
    : []

  if (name.length < 2 || name.length > 100) return { ok: false, message: 'Informe seu nome completo.' }
  if (response !== 'yes' && response !== 'no') return { ok: false, message: 'Escolha se você poderá comparecer.' }
  if (companions.some((item) => item.length < 2 || item.length > 100)) {
    return { ok: false, message: 'Revise o nome dos acompanhantes.' }
  }

  try {
    const payload = await getPayload({ config })
    const data = {
      name,
      response,
      companions: response === 'yes' ? companions.map((companionName) => ({ name: companionName })) : [],
      editToken: input.id ? input.editToken || '' : 'pending',
    }

    const doc = input.id
      ? await payload.update({ collection: 'rsvps', id: input.id, data, overrideAccess: false })
      : await payload.create({ collection: 'rsvps', data, overrideAccess: false })

    if (!doc.editToken) return { ok: false, message: 'Não foi possível criar a chave de edição.' }
    return { ok: true, id: doc.id, editToken: doc.editToken }
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Tente novamente em instantes.'
    return { ok: false, message: message.includes('limite') ? message : 'Não foi possível salvar sua resposta. Tente novamente.' }
  }
}

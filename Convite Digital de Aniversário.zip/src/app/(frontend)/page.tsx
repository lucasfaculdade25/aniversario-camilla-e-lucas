import Image from 'next/image'
import { getInvitation } from '@/lib/invitation'
import { Icon } from './components/icons'
import { RSVPFlow } from './components/rsvp-flow'

function mediaUrl(image: unknown) {
  return image && typeof image === 'object' && 'url' in image && typeof image.url === 'string' ? image.url : null
}

function formatDate(value: string) {
  const date = new Date(value)
  return {
    numeric: new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', timeZone: 'UTC' }).format(date),
    full: new Intl.DateTimeFormat('pt-BR', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric', timeZone: 'UTC' }).format(date),
  }
}

export default async function HomePage() {
  const invitation = await getInvitation()
  const eventDate = invitation.date || '2026-11-21T12:00:00.000Z'
  const rsvpDeadline = invitation.rsvpDeadline || '2026-11-10T12:00:00.000Z'
  const date = formatDate(eventDate)
  const deadline = formatDate(rsvpDeadline).full
  const hero = mediaUrl(invitation.heroImage)
  const accent = invitation.appearance?.accent || '#B64A32'
  const background = invitation.appearance?.background || '#F4EFE8'
  const ink = invitation.appearance?.ink || '#20231F'
  const calendarStart = eventDate.slice(0, 10).replaceAll('-', '') + 'T' + invitation.time.replace(':', '') + '00'
  const calendarUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(invitation.title)}&dates=${calendarStart}/${calendarStart}&location=${encodeURIComponent(`${invitation.venue}, ${invitation.address}`)}`

  return (
    <main
      style={{ '--accent': accent, '--paper': background, '--ink': ink } as React.CSSProperties}
      className="min-h-screen bg-white text-[var(--ink)]"
    >
      <div className="lg:grid lg:grid-cols-[minmax(420px,42vw)_1fr]">
        <aside className="relative h-[58svh] overflow-hidden bg-[var(--ink)] lg:sticky lg:top-0 lg:h-screen">
          {hero ? (
            <Image
              src={hero}
              alt={`Celebração de ${invitation.hosts}`}
              fill
              priority
              className="object-cover"
              sizes="(min-width: 1024px) 42vw, 100vw"
            />
          ) : (
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,#9b5a43,transparent_45%),linear-gradient(145deg,#24251f,#4a4034)]" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-black/10" />
          <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-6 text-white sm:p-9">
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.28em] text-white/70">{invitation.eyebrow}</p>
              <p className="font-display mt-2 text-2xl italic">{invitation.hosts}</p>
            </div>
            <span className="rounded-full border border-white/30 bg-black/10 px-4 py-2 text-[11px] font-medium backdrop-blur-md">
              {date.numeric}
            </span>
          </div>
        </aside>

        <div className="relative min-w-0">
          <nav className="fixed right-5 top-1/2 z-20 hidden -translate-y-1/2 flex-col overflow-hidden rounded-full border border-black/10 bg-white/85 p-1.5 shadow-lg backdrop-blur-xl xl:flex">
            <a href="#informacoes" className="group relative grid size-11 place-items-center rounded-full text-black/45 transition hover:bg-[var(--accent)] hover:text-white" aria-label="Informações">
              <Icon name="calendar" className="size-4.5" />
              <span className="pointer-events-none absolute right-14 whitespace-nowrap rounded-md bg-[var(--ink)] px-2.5 py-1.5 text-[10px] font-semibold text-white opacity-0 transition group-hover:opacity-100">Informações</span>
            </a>
            <a href="#mensagem" className="group relative grid size-11 place-items-center rounded-full text-black/45 transition hover:bg-[var(--accent)] hover:text-white" aria-label="Mensagem">
              <span className="size-4 rounded-sm border-[1.5px] border-current after:ml-1 after:mt-3.5 after:block after:size-1.5 after:rotate-45 after:border-b after:border-r after:border-current" />
              <span className="pointer-events-none absolute right-14 whitespace-nowrap rounded-md bg-[var(--ink)] px-2.5 py-1.5 text-[10px] font-semibold text-white opacity-0 transition group-hover:opacity-100">Mensagem</span>
            </a>
            <a href="#rsvp" className="group relative grid size-11 place-items-center rounded-full text-black/45 transition hover:bg-[var(--accent)] hover:text-white" aria-label="Confirmar presença">
              <Icon name="check" className="size-4.5" />
              <span className="pointer-events-none absolute right-14 whitespace-nowrap rounded-md bg-[var(--ink)] px-2.5 py-1.5 text-[10px] font-semibold text-white opacity-0 transition group-hover:opacity-100">Confirmar</span>
            </a>
          </nav>

          <section id="informacoes" className="flex min-h-screen items-center px-6 py-16 sm:px-10 lg:px-[clamp(3rem,7vw,7rem)] lg:py-20">
            <div className="w-full max-w-2xl">
              <p className="text-[11px] font-semibold uppercase tracking-[0.26em] text-[var(--accent)]">{invitation.eyebrow}</p>
              <h1 className="font-display mt-4 max-w-xl text-5xl leading-[.98] tracking-[-0.035em] sm:text-6xl">{invitation.title}</h1>
              <p className="mt-4 text-sm font-semibold text-black/48">{invitation.hosts}</p>

              <RSVPFlow
                companionLimit={Number(invitation.companionLimit ?? 0)}
                allowCompanions={Boolean(invitation.allowCompanions)}
                deadline={deadline}
              />

              <div className="mt-10 space-y-7 border-t border-black/10 pt-8">
                <div className="grid grid-cols-[36px_1fr] gap-3">
                  <span className="grid size-9 place-items-center rounded-full bg-[var(--paper)] text-[var(--accent)]"><Icon name="calendar" className="size-4.5" /></span>
                  <div>
                    <p className="text-base font-semibold capitalize">{date.full}</p>
                    <p className="mt-1 text-sm text-black/55">A partir das {invitation.time}</p>
                    <a href={calendarUrl} target="_blank" rel="noreferrer" className="mt-2 inline-flex items-center gap-2 text-sm font-semibold text-[var(--accent)] underline decoration-black/15 underline-offset-4">Adicionar ao calendário <Icon name="arrow" className="size-3.5 -rotate-45" /></a>
                  </div>
                </div>

                <div className="grid grid-cols-[36px_1fr] gap-3">
                  <span className="grid size-9 place-items-center rounded-full bg-[var(--paper)] text-[var(--accent)]"><Icon name="map" className="size-4.5" /></span>
                  <div>
                    <p className="text-base font-semibold">{invitation.venue}</p>
                    <p className="mt-1 max-w-lg text-sm leading-6 text-black/55">{invitation.address}</p>
                    <a href={invitation.mapsUrl} target="_blank" rel="noreferrer" className="mt-2 inline-flex items-center gap-2 text-sm font-semibold text-[var(--accent)] underline decoration-black/15 underline-offset-4">Ver no Google Maps <Icon name="arrow" className="size-3.5 -rotate-45" /></a>
                  </div>
                </div>
              </div>

              <a href={invitation.mapsUrl} target="_blank" rel="noreferrer" className="group relative mt-10 block h-44 overflow-hidden rounded-2xl border border-black/10 bg-[var(--paper)]">
                <div className="absolute inset-0 opacity-45 [background-image:linear-gradient(30deg,transparent_48%,rgba(32,35,31,.16)_49%,rgba(32,35,31,.16)_51%,transparent_52%),linear-gradient(150deg,transparent_48%,rgba(32,35,31,.12)_49%,rgba(32,35,31,.12)_51%,transparent_52%)] [background-size:90px_70px]" />
                <div className="absolute left-[58%] top-[48%] size-5 -translate-x-1/2 -translate-y-1/2 rounded-full border-[6px] border-[var(--accent)] bg-white shadow-[0_4px_12px_rgba(0,0,0,.2)]" />
                <span className="absolute left-4 top-4 rounded-lg bg-white px-3 py-2 text-xs font-semibold shadow-sm transition group-hover:-translate-y-0.5">Abrir localização</span>
                <span className="absolute bottom-4 right-4 grid size-9 place-items-center rounded-full bg-white shadow-sm"><Icon name="arrow" className="size-4 -rotate-45" /></span>
              </a>
            </div>
          </section>

          <section id="mensagem" className="flex min-h-screen items-center border-t border-black/5 bg-[var(--paper)] px-6 py-20 sm:px-10 lg:px-[clamp(3rem,7vw,7rem)]">
            <div className="max-w-2xl">
              <p className="text-[11px] font-semibold uppercase tracking-[0.26em] text-[var(--accent)]">Uma mensagem para você</p>
              <h2 className="font-display mt-4 text-5xl leading-[1.02] tracking-[-0.03em] sm:text-6xl">Comemorar é estar perto.</h2>
              <div className="mt-9 h-px w-14 bg-[var(--accent)]" />
              <p className="font-display mt-9 text-2xl leading-[1.55] text-[var(--ink)] sm:text-3xl">{invitation.message}</p>
              <p className="mt-10 text-xs font-semibold uppercase tracking-[0.22em] text-black/45">Com carinho, {invitation.hosts}</p>
              <a href="#informacoes" className="mt-12 inline-flex items-center gap-3 text-sm font-semibold text-[var(--accent)]">Rever informações <Icon name="arrow" className="size-4 rotate-180" /></a>
            </div>
          </section>

          <footer className="flex flex-col items-start justify-between gap-3 bg-[var(--ink)] px-6 py-8 text-xs text-white/45 sm:flex-row sm:items-center sm:px-10">
            <span className="font-display text-base italic text-white/80">{invitation.hosts}</span>
            <span>Feito para celebrar o que realmente importa.</span>
          </footer>
        </div>
      </div>
    </main>
  )
}
